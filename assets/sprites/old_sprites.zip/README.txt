This is a collection of old sprites made by me and my brother forever ago.
You are free to redistribute them under the terms of either the Creative
Commons - Attribution - Share Alike license (CC-BY-SA) or the GNU GPL
(whichever is more convenient for you). Where appropriate, please attribute
them to:

Barry "Ishara" Peddycord <http://isharacomix.com>
William "Ihara" Peddycord <http://ihara.deviantart.com>

The terms of the GPL are available in the COPYING_GPL.txt file, and the terms
of the CC-BY-SA license are available in the COPYING_CC_BY_SA.txt file.

Hopefully you can do more with them than we did! :)

